COPYRIGHT Zen Robotics inc. 

-INSTALL: you don't really need to install anything, just make sure you got your raspberry pi updated. You put the PC version application where thr root directory of your custom application is and have it executed when you app starts.
The same thing for the raspberry pi version. The libraries are for you to have an easy implementation of an interface to the RaspberryPI remote app. Right now C# and maybe VB.net is built, soon will be more.